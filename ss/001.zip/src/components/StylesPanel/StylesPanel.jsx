import { useState } from "react";
import { Search, Pencil, Settings, ChevronDown, ChevronsUp, Pin, X } from "lucide-react";
import TreeNode from "../TreeNode/TreeNode";
import { treeData } from "../../data/treeData";
import { placeholderUrl } from "../../utils/placeholder";
import "./StylesPanel.css";

export default function StylesPanel() {
  const [query, setQuery] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState("wall");
  const [selectedItemId, setSelectedItemId] = useState("w8");
  const [expandedIds, setExpandedIds] = useState(new Set(["wall"]));

  const activeCategory =
    treeData.find((n) => n.id === selectedCategoryId) || treeData[0];
  const items = activeCategory.items || [];

  const filteredItems = query
    ? items.filter((it) =>
        it.lines.join(" ").toLowerCase().includes(query.toLowerCase())
      )
    : items;

  function toggleExpand(id) {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  return (
    <div className="styles-panel">
      {/* Title bar */}
      <div className="styles-panel__titlebar">
        <span>Styles</span>
        <div className="styles-panel__titlebar-icons">
          <Pin size={13} />
          <X size={13} />
        </div>
      </div>

      {/* Active style summary / dropdown 
      <div className="styles-panel__summary-row">
        <div className="styles-panel__summary">
          <div className="styles-panel__summary-text">
            <div className="styles-panel__summary-category">
              Architectural elements - Wall
            </div>
            <div className="styles-panel__summary-current">
              1 layered 38 wide wall
            </div>
          </div>
          <ChevronDown size={16} color="#6b6b6b" />
        </div>
      </div>*/}

      {/* Search row */}
      <div className="styles-panel__search-row">
        <div className="styles-panel__search-box">
          <input
            className="styles-panel__search-input"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search"
          />
          <Search size={14} color="#6b6b6b" />
        </div>
        <button className="styles-panel__icon-button">
          <Pencil size={13} color="#6b6b6b" />
        </button>
        <button className="styles-panel__icon-button">
          <Settings size={13} color="#6b6b6b" />
        </button>
      </div>

      {/* "Recent" collapse bar 
      <div className="styles-panel__recent-bar">
        <ChevronsUp size={12} />
        <span>Recent</span>
      </div>
    */}


      {/* Body: tree + grid */}
      <div className="styles-panel__body">
        <div className="styles-panel__tree styles-panel-scroll">
          {treeData.map((node) => (
            <TreeNode
              key={node.id}
              node={node}
              depth={0}
              selectedId={selectedCategoryId}
              onSelect={setSelectedCategoryId}
              expandedIds={expandedIds}
              onToggle={toggleExpand}
            />
          ))}
        </div>

        <div className="styles-panel__grid styles-panel-scroll">
          {filteredItems.map((item) => {
            const isSelected = selectedItemId === item.id;
            return (
              <div
                key={item.id}
                className={`styles-panel__grid-item ${
                  isSelected ? "styles-panel__grid-item--selected" : ""
                }`}
                onClick={() => setSelectedItemId(item.id)}
              >
                <img
                  className="styles-panel__thumb"
                  src={placeholderUrl(item.color)}
                  alt={item.lines.join(" ")}
                  width={84}
                  height={112}
                />
                <div className="styles-panel__caption">
                  <div>{item.lines[0]}</div>
                  <div>{item.lines[1]}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
